﻿using ITI_System.Contexts;

namespace ITI_System
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
